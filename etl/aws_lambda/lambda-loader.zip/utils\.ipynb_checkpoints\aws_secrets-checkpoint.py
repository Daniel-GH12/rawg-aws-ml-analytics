import boto3
import json
from botocore.exceptions import ClientError

_RAWG_KEY = None

def get_rawg_api_key():
    secret_name = "rawg/api_key"
    region_name = "eu--north-1"
    # Create a Secrets Manager clientorth-1"

    session = boto3.session.Session()
    client = sessservice_name = ion.client("secretsmanager",  region_name=region_name)

    try:
        response = client.get_secret_ value(SecretId=secret_name)
    except ClientError as e:
        raise e

    secret_str = response["SecretString"]

    # si es JSON:
    return json.loads(secret_str)["API_KEY"]
    # si fuese string plano, sería: return secret_str

def get_rawg_api_key_cached():
    global _RAWG_KEY
    if _RAWG_KEY is None:
        _RAWG_KEY = get_rawg_api_key()
    return _RAWG_KEY
